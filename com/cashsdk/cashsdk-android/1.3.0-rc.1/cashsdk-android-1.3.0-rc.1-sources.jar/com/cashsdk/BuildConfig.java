/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.cashsdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.cashsdk";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String CASHSDK_VERSION = "1.3.0-rc.1";
}
